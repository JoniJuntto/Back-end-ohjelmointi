package com.example.exc1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Exc1Application {

	public static void main(String[] args) {
		SpringApplication.run(Exc1Application.class, args);
	}

}
