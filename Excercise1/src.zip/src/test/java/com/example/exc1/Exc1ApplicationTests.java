package com.example.exc1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Exc1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
